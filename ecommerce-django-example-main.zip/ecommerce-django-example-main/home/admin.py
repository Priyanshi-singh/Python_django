from django.contrib import admin
from .models import Slider, Contact
# Register your models here.

admin.site.register(Slider)
admin.site.register(Contact)